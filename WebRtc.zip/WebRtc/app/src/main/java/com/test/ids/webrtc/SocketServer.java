package com.test.ids.webrtc;

import android.os.Handler;
import android.os.Message;
import android.util.Log;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Inet4Address;
import java.net.Inet6Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Enumeration;


public class SocketServer implements Runnable {
    private ServerSocket serverSocket;
    private Socket clientSocket;
    private PrintWriter out;
    private BufferedReader in;
    private Handler handler;
    private String ipAddress = "";
    private boolean onOpened = true;

    private int what = 1;

    private boolean connect = false;

    public boolean isOnOpened() {
        return onOpened;
    }

    public void setOnOpened(boolean onOpened) {
        this.onOpened = onOpened;
    }



    public static ArrayList<Socket> socketList = new ArrayList<Socket>();

    public SocketServer(Handler handler) {
        this.handler = handler;
    }

    //MainActivityでstartSocketServerが動くとこれが働く
    public void run(){

        try{
            // Open a server socket listening on port 8080
            InetAddress addr = InetAddress.getByName(getLocalIpAddress());
            serverSocket = new ServerSocket(9002, 0, addr);
            //clientSocket = serverSocket.accept();

            while (onOpened) {
                clientSocket = serverSocket.accept();
                new EchoThread(clientSocket,this.handler).start();
            }

        } catch(Exception e) {
            // Omitting exception handling for clarity
        }
    }

    public void closeSocket(){
        // Perform cleanup
        try {
            if(clientSocket != null) {
                clientSocket.close();
                clientSocket = null;
            }
            serverSocket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        this.what = 1;
    }

    public void closeClientSocket(){
        // Perform cleanup
        try {
            if(clientSocket != null) {
                clientSocket.close();
                clientSocket = null;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private String getLocalIpAddress() throws Exception {
        String resultIpv6 = "";
        String resultIpv4 = "";

        for (Enumeration en = NetworkInterface.getNetworkInterfaces();
             en.hasMoreElements();) {

            NetworkInterface intf = (NetworkInterface) en.nextElement();
            for (Enumeration enumIpAddr = intf.getInetAddresses();
                 enumIpAddr.hasMoreElements();) {

                InetAddress inetAddress = (InetAddress) enumIpAddr.nextElement();
                if(!inetAddress.isLoopbackAddress()){
                    if (inetAddress instanceof Inet4Address) {
                        resultIpv4 = inetAddress.getHostAddress().toString();
                    } else if (inetAddress instanceof Inet6Address) {
                        resultIpv6 = inetAddress.getHostAddress().toString();
                    }
                }
            }
        }
        return ((resultIpv4.length() > 0) ? resultIpv4 : resultIpv6);
    }

    public boolean isConnect() {
        return connect;
    }

    public void setConnect(boolean connect) {
        this.connect = connect;
    }

    class EchoThread extends Thread {

        private Socket clientSocket;
        private Handler handler2;
        private String type = "";
        private String data = "";

        public EchoThread(Socket socket,Handler handler) {
            clientSocket = socket;
            handler2 = handler;

            System.out.println("接続されました "
                    + clientSocket.getRemoteSocketAddress());

            if(connect == true)
            {
                what= 2;
            }
        }

        public void run() {
            ipAddress = clientSocket.getRemoteSocketAddress().toString().replace("/", "").split(":")[0];
            Message msg = null;

            Log.d("WebRTC:what", String.valueOf(what));
            if (what == 1) {
                //接続確認
                Log.d("WebRTC:ipAddress", ipAddress);
                msg = Message.obtain(handler2, what, ipAddress);
                handler2.sendMessage(msg);
                what++;
                try {
                    out = new PrintWriter(clientSocket.getOutputStream(), true);
                    out.println("received: " + ipAddress);
                    //out.close();

                } catch (IOException e) {
                    e.printStackTrace();

                }
            }
            else
            {
                    //android同士の接続
                    String message = "";

                    try {
                        DataInputStream is;
                        is = new DataInputStream(clientSocket.getInputStream());
                        BufferedReader in = new BufferedReader(new InputStreamReader(is));

                        while ((message = in.readLine()) != null){
                            if(message.equals("hangup")) {
                                msg = Message.obtain(handler2, 3, "hangup");
                                handler2.sendMessage(msg);
                            }
                            else {
                                msg = Message.obtain(handler2, 2, message);
                                handler2.sendMessage(msg);
                            }
                        }

                    } catch (IOException e) {
                        e.printStackTrace();
                    }
            }
        }
    }

}

