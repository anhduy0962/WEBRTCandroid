package com.test.ids.webrtc;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.WindowManager;
import android.webkit.ConsoleMessage;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.NetworkInterface;
import java.net.Socket;
import java.net.SocketException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Enumeration;

import static java.lang.System.in;


public class MainActivity extends AppCompatActivity {

    private static final String AUTH_PENDING = "auth_state_pending";
    static final int REQUEST_CODE = 1;

    private SocketServer socketServer;
    private Handler handler;

    private WebView webView;

    private boolean startVideo = false;
    private Handler handler2 = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // インスタンスを作る
        final SampleClass sampleClass = new SampleClass();

        handler = new Handler() {
            @Override
            public void handleMessage(Message msg) {
                Log.d("WebRTC", (String)msg.obj);
                switch (msg.what) {
                    case 1:
                            sampleClass.setIPAddress((String) msg.obj);
                            webView.loadUrl("javascript:toConnect('" + (String) msg.obj + "');");
                        break;
                    case 2:
                        Log.d("WebRTC", "received:mes");
                        try {
                            JSONObject json = new JSONObject((String)msg.obj);
                            webView.loadUrl("javascript:onMessage(" + json + ");");
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        break;
                    case 3:
                        Log.d("WebRTC", "received:hangup");
                        webView.loadUrl("javascript:hangup();");
                        break;
                }
            }
        };

        //カメラのパーミッションチェック
        boolean permissionCheck = permissionCheck();

        if(permissionCheck) {
            startSocketServer();

            //WebViewの設定
            webView = (WebView) findViewById(R.id.webView);
            //WebViewClientの関連づけ
            //ページロード完了時の処理を設定
            webView.setWebViewClient(new ViewClient());
            // JavaScriptを有効化
            webView.getSettings().setJavaScriptEnabled(true);
            webView.loadUrl("file:///android_asset/webrtc_android.html");
            webView.addJavascriptInterface(sampleClass, "android");

            webView.setWebChromeClient(new WebChromeClient(){
                @Override
                public void onPermissionRequest(final PermissionRequest request) {
                    request.grant(request.getResources());
                }

                //デバッグ用
                @Override
                public boolean onConsoleMessage(ConsoleMessage cm) {
                    Log.i("WebRTC", "\n[" + cm.messageLevel() + "] " + cm.message() + " - " + cm.sourceId() + "：" + cm.lineNumber() + "行目");
                    return true;
                }
            });

            // HTML5 Video support のため
            getWindow().setFlags(
                    WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                    WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED);
        }


    }

    @Override
    protected void onPause() {
        super.onPause();

        if(startVideo) {
            webView.loadUrl("javascript:stopVideo();");
        }
    }

    @Override
    protected void onResume() {
        super.onResume();

        if(socketServer == null) {
            startSocketServer();
        }

        if(startVideo)
        {
            webView.loadUrl("javascript:startVideo();");
        }
    }

    @Override
    protected void onStop() {
        super.onStop();

        //socketServerを停止する
        if(socketServer != null) {
            socketServer.closeSocket();
            socketServer = null;
        }
    }

    private void startSocketServer()
    {
        //socketServerの起動
        socketServer = new SocketServer(handler);
        Thread thread = new Thread(socketServer);
        thread.start();
    }

    //WebViewClientを継承
    @SuppressLint("HandlerLeak")
    public final class ViewClient extends WebViewClient {
        //ページロード完了時に行う
        @Override
        public void onPageFinished(final WebView webView , String url) {

        }
    }

    private boolean permissionCheck()
    {
        boolean res = false;

        //カメラのパーミッションチェック
        int permissionCheck = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA);

        if(permissionCheck == PackageManager.PERMISSION_GRANTED)
        {
            permissionCheck = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA);
        }

        if (permissionCheck != PackageManager.PERMISSION_GRANTED) {

            // Android 6.0 のみ、該当パーミッションが許可されていない場合
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.CAMERA)) {
                // パーミッションが必要であることを明示するアプリケーション独自のUIを表示
            }
            else
            {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, REQUEST_CODE);
                res = true;
            }

        } else {
            res = true;
        }

        return res;
    }

    // クラスの定義
    public class SampleClass{
        private double a;
        private String ipAddress = "";
        private Socket connection = null;
        private DataOutputStream os;

        public void setIPAddress(String ipAddress)
        {
            this.ipAddress = ipAddress;
        }

        public String getIpAddress()
        {
            return this.ipAddress;
        }

        @JavascriptInterface //呼び出すメソッドにこの指定が必要
        public double getA() {
            Log.i("HTML", "test()");
            return this.a;
        }

        @JavascriptInterface
        public void onOpened()
        {
            Log.d("WebRTC", "onOpened");

            socketServer.setOnOpened(false);
        }

        @JavascriptInterface
        public void startVideo()
        {
            startVideo = true;
        }

        @JavascriptInterface
        public void stopVideo()
        {
            startVideo = false;
        }

        @JavascriptInterface
        public void setFQDN(final String FQDN) throws IOException {
            handler2.post(new Runnable() {
                @Override
                public void run() {
                    Log.i("HTML", "setFQDN:" + FQDN);
                    String cmd = "ping -n -c 1 " + FQDN; //実行するコマンド

                    Runtime runtime = Runtime.getRuntime();

                    Process p = null;
                    try {
                        p = runtime.exec(cmd);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                    InputStream is = p.getInputStream();
                    InputStreamReader isr = null;
                    try {
                        isr = new InputStreamReader(is, "Shift-JIS");
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    }
                    BufferedReader reader = new BufferedReader(isr);

                    String res = null;
                    try {
                        res = reader.readLine();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    System.out.println(res);

                    int start = res.indexOf("(") + 1;
                    int end = res.indexOf(")");
                    res = res.substring(start,end);
                    System.out.println(res);
                    webView.loadUrl("javascript:toPING('"+res+"');");
                }
            });
        }

        @JavascriptInterface
        public void getFQDN()
        {
            handler2.post(new Runnable() {
                @Override
                public void run() {
                    Log.i("HTML", "getip()");
                    webView.loadUrl("javascript:toFQDN();");
                }
            });
        }

        @JavascriptInterface
        public boolean androidConnectTest(String ipAddress)
        {
            this.ipAddress = ipAddress;

            BufferedReader reader = null;
            // サーバーへ接続
            try {
                this.connection = new Socket(ipAddress, 9002);
            } catch (IOException e) {
                e.printStackTrace();
            }
            finally {
                // 接続終了処理
                try {
                    if(this.connection != null) {
                        this.connection.close();
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }
            return false;
        }

        @JavascriptInterface
        public boolean androidConnect()
        {
            try {
                Log.d("WebRTC", "androidConnect");
                this.connection = new Socket(this.ipAddress, 9002);
                os = new DataOutputStream(this.connection.getOutputStream());
                socketServer.setConnect(true);
                return true;
            } catch (IOException e) {
                e.printStackTrace();
                return  false;
            }finally {

            }
        }

        @JavascriptInterface
        public boolean sendMessage(String mes)  {
            Log.d("WebRTC", "sendMessage" + mes);
            try {
                PrintWriter pw = new PrintWriter(os);
                pw.println(mes);
                pw.flush();
                os.flush();
                return true;
            } catch (IOException e) {
                e.printStackTrace();
            }
            return false;
        }

        @JavascriptInterface
        public boolean hangup()  {
            Log.d("WebRTC", "hangup");
            try {
                PrintWriter pw = new PrintWriter(os);
                pw.println("hangup");
                pw.flush();
                os.flush();
            } catch (IOException e) {
                e.printStackTrace();
            }

            try {
                os.close();
                this.connection.close();
                closeSocket();
                startSocketServer();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return true;
        }

        @JavascriptInterface
        public boolean isExistURL(String urlStr) {

            URL url;
            int status = 0;
            try {
                url = new URL(urlStr);
                HttpURLConnection connection = (HttpURLConnection)url.openConnection();
                connection.setRequestMethod("HEAD");
                connection.connect();
                status = connection.getResponseCode();
                connection.disconnect();
            } catch (MalformedURLException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }

            if (status == HttpURLConnection.HTTP_OK) {
                return true;
            } else {
                return false;
            }
        }

        @JavascriptInterface
        public void closeSocket()
        {
            //socketServerを停止する
            if(socketServer != null) {
                socketServer.closeSocket();
                socketServer = null;
            }
        }
    }
}
